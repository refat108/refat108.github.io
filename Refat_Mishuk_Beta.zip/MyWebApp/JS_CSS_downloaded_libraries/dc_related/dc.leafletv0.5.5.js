/*!
 *  dc.leaflet 0.5.5
 *  http://dc-js.github.io/dc.leaflet.js/
 *  Copyright 2014-2015 Boyan Yurukov and the dc.leaflet Developers
 *  https://github.com/dc-js/dc.leaflet.js/blob/master/AUTHORS
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

!(function () {
  function a(a, b, c) {
    "use strict";
    var d = { version: "0.5.5" };
    return (
      (d.leafletBase = function (a) {
        var b = new a();
        b.margins({ left: 0, top: 0, right: 0, bottom: 0 });
        var d,
          e = !1,
          f = !1,
          g = !1,
          h = !1,
          i = null,
          j = null,
          k = {},
          l = function (a) {
            var d = a.selectAll("div.dc-leaflet");
            return (
              (d = d
                .data([0])
                .enter()
                .append("div")
                .attr("class", "dc-leaflet")
                .style("width", b.effectiveWidth() + "px")
                .style("height", b.effectiveHeight() + "px")
                .merge(d)),
              c.map(d.node(), f)
            );
          },
          m = function (a) {
            c.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
              attribution:
                '&copy; <a href="https://openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            }).addTo(a);
          };
        (b.createLeaflet = function (a) {
          return arguments.length ? ((l = a), b) : l;
        }),
          (b._doRender = function () {
            if (b.map())
              b.map() && e
                ? b._postRender()
                : console.warn("WARNING: Leaflet map already rendered.");
            else {
              d = l(b.root());
              for (var a in k) d.on(a, k[a]);
              g && h && d.setView(b.toLocArray(g), h),
                b.tiles()(d),
                b._postRender();
            }
            return b._doRedraw();
          }),
          (b._doRedraw = function () {
            return b;
          }),
          (b._postRender = function () {
            return b;
          }),
          (b.mapOptions = function (a) {
            return arguments.length ? ((f = a), b) : f;
          }),
          (b.center = function (a) {
            return arguments.length ? ((g = a), b) : g;
          }),
          (b.zoom = function (a) {
            return arguments.length ? ((h = a), b) : h;
          }),
          (b.tiles = function (a) {
            return arguments.length ? ((m = a), b) : m;
          }),
          (b.map = function (a) {
            return arguments.length ? ((d = a), (e = !0), b) : d;
          }),
          (b._isMac = navigator.platform.toUpperCase().includes("MAC")),
          (b._modAssignment = {
            shift: "shiftKey",
            alt: "altKey",
            ctrlCmd: b._isMac ? "metaKey" : "ctrlKey"
          }),
          (b.popupMod = function (a) {
            return arguments.length ? ((i = a), b) : i;
          }),
          (b.filterMod = function (a) {
            return arguments.length ? ((j = a), b) : j;
          }),
          (b.modKeyMatches = function (a, c) {
            return c
              ? a.originalEvent[b._modAssignment[c]]
              : !(
                  a.originalEvent.shiftKey ||
                  a.originalEvent.altKey ||
                  a.originalEvent.ctrlKey ||
                  a.originalEvent.metaKey
                );
          }),
          (b.bindPopupWithMod = function (a, c) {
            a.bindPopup(c),
              a.off("click", a._openPopup),
              a.on("click", function (c) {
                b.modKeyMatches(c, b.popupMod()) && a._openPopup(c);
              });
          }),
          (b.toLocArray = function (a) {
            return "string" == typeof a && (a = a.split(",")), a;
          });
        const n = b.on;
        return (
          (b.on = function (a, b) {
            var c = ["zoomend", "moveend"];
            return c.indexOf(a) >= 0
              ? (d ? d.on(a, b) : (k[a] = b), this)
              : n.call(this, a, b);
          }),
          b
        );
      }),
      (d.legend = function () {
        function a() {
          return c.Control.extend({
            options: { position: f },
            onAdd: function (a) {
              return (
                a.legend ? a.legend.setContent("") : (a.legend = this),
                (this._div = c.DomUtil.create("div", "info legend")),
                a.on("moveend", this._update, this),
                this._update(),
                this._div
              );
            },
            setContent: function (a) {
              return (this.getContainer().innerHTML = a);
            },
            _update: function () {
              if (b.colorDomain) {
                var a,
                  d = b.colorDomain()[0],
                  e = b.colorDomain()[1],
                  f = b.colors().range(),
                  h = b.colors().range().length,
                  i = (e - d) / h,
                  j = [];
                for (j[0] = Math.round(d), a = 1; a < h; a++)
                  j[a] = Math.round((0.5 + (a - 1)) * i + d);
                c.DomUtil.create("div", "info legend");
                for (
                  g
                    ? (this._div.innerHTML = "<strong>" + g + "</strong><br/>")
                    : (this._div.innerHTML = ""),
                    a = 0;
                  a < j.length;
                  a++
                )
                  this._div.innerHTML +=
                    '<i style="background:' +
                    f[a] +
                    '"></i> ' +
                    j[a] +
                    (j[a + 1] ? "&ndash;" + j[a + 1] + "<br>" : "+");
              } else
                console.warn(
                  "legend not supported for this dc.leaflet chart type, ignoring"
                );
            }
          });
        }
        var b,
          d = {},
          e = null,
          f = "bottomleft",
          g = !1;
        return (
          (d.parent = function (a) {
            return arguments.length ? ((b = a), this) : b;
          }),
          (d.LegendClass = function (b) {
            return arguments.length ? ((a = b), d) : a;
          }),
          (d.legendTitle = function (a) {
            return arguments.length ? ((g = a), d) : g;
          }),
          (d.render = function () {
            if (!e) {
              var a = d.LegendClass()();
              (e = new a()), e.addTo(b.map());
            }
            return d.redraw();
          }),
          (d.redraw = function () {
            return e._update(), d;
          }),
          (d.leafletLegend = function () {
            return e;
          }),
          (d.position = function (a) {
            return arguments.length ? ((f = a), d) : f;
          }),
          d
        );
      }),
      (d.markerChart = function (b, e) {
        var f = d.leafletBase(a.MarginMixin),
          g = !0,
          h = !1,
          i = !1,
          j = !1,
          k = !0,
          l = !1,
          m = !1,
          n = !1,
          o = !1,
          p = !1,
          q = !1,
          r = [],
          s = !1,
          t = !0,
          u = !1,
          v = !1,
          w = !0,
          x = function (a) {
            return f.keyAccessor()(a);
          },
          y = function (a, b) {
            var d = new c.Marker(f.toLocArray(f.locationAccessor()(a)), {
              title: w ? f.title()(a) : "",
              alt: w ? f.title()(a) : "",
              icon: z(a, b),
              clickable: f.renderPopup() || (f.brushOn() && !l),
              draggable: !1
            });
            return d;
          },
          z = function (a, b) {
            return new c.Icon.Default();
          },
          A = function (a, b) {
            return f.title()(a);
          };
        (f._postRender = function () {
          f.brushOn() &&
            (l && f.filterHandler(E),
            f.map().on("zoomend moveend", D, this),
            l || f.map().on("click", D, this),
            f.map().on("zoomstart", C, this)),
            (q = h
              ? new c.MarkerClusterGroup(i ? i : null)
              : new c.LayerGroup()),
            f.map().addLayer(q);
        }),
          (f._doRedraw = function () {
            var a = f._computeOrderedGroups(f.data()).filter(function (a) {
              return 0 !== f.valueAccessor()(a);
            });
            if (!s || s.toString() !== a.toString()) {
              (s = a), j && (r = []), q.clearLayers();
              var b = [];
              (n = !1),
                a.forEach(function (a, c) {
                  var d = f.keyAccessor()(a),
                    e = null;
                  (e = !j && d in r ? r[d] : B(a, d)),
                    f.cluster() ? b.push(e) : q.addLayer(e);
                }),
                f.cluster() && b.length > 0 && q.addLayers(b),
                b.length > 0 &&
                  (t || (u && !v)) &&
                  ((n = new c.featureGroup(b)),
                  f.map().fitBounds(n.getBounds())),
                (v = !1),
                (t = !1);
            }
          }),
          (f.locationAccessor = function (a) {
            return arguments.length ? ((x = a), f) : x;
          }),
          (f.marker = function (a) {
            return arguments.length ? ((y = a), f) : y;
          }),
          (f.featureGroup = function (a) {
            return arguments.length ? ((n = a), f) : n;
          }),
          (f.icon = function (a) {
            return arguments.length ? ((z = a), f) : z;
          }),
          (f.popup = function (a) {
            return arguments.length ? ((A = a), f) : A;
          }),
          (f.clickEvent = function (a) {
            return arguments.length ? ((m = a), f) : m;
          }),
          (f.renderPopup = function (a) {
            return arguments.length ? ((g = a), f) : g;
          }),
          (f.cluster = function (a) {
            return arguments.length ? ((h = a), f) : h;
          }),
          (f.clusterOptions = function (a) {
            return arguments.length ? ((i = a), f) : i;
          }),
          (f.rebuildMarkers = function (a) {
            return arguments.length ? ((j = a), f) : j;
          }),
          (f.brushOn = function (a) {
            return arguments.length ? ((k = a), f) : k;
          }),
          (f.filterByArea = function (a) {
            return arguments.length ? ((l = a), f) : l;
          }),
          (f.fitOnRender = function (a) {
            return arguments.length ? ((t = a), f) : t;
          }),
          (f.fitOnRedraw = function (a) {
            return arguments.length ? ((u = a), f) : u;
          }),
          (f.showMarkerTitle = function (a) {
            return arguments.length ? ((w = a), f) : w;
          }),
          (f.markerGroup = function () {
            return q;
          });
        var B = function (a, b) {
            var c = y(a, f.map());
            return (
              (c.key = b),
              f.renderPopup() && f.bindPopupWithMod(c, f.popup()(a, c)),
              f.brushOn() && !l && c.on("click", F),
              m && c.on("click", m),
              (r[b] = c),
              c
            );
          },
          C = function (a) {
            p = !0;
          },
          D = function (b) {
            if ("moveend" !== b.type || (!p && !b.hard))
              if (((p = !1), l)) {
                var c;
                (c =
                  f.map().getCenter().equals(f.center()) &&
                  f.map().getZoom() === f.zoom()
                    ? null
                    : f.map().getBounds()),
                  a.events.trigger(function () {
                    f.filter(null),
                      c && ((o = !0), f.filter(c), (o = !1)),
                      a.redrawAll(f.chartGroup());
                  });
              } else
                f.filter() &&
                  ("click" === b.type ||
                    (r.indexOf(f.filter()) !== -1 &&
                      !f
                        .map()
                        .getBounds()
                        .contains(r[f.filter()].getLatLng()))) &&
                  a.events.trigger(function () {
                    f.filter(null),
                      g && f.map().closePopup(),
                      a.redrawAll(f.chartGroup());
                  });
          },
          E = function (a, b) {
            f.dimension().filter(null),
              b &&
                b.length > 0 &&
                (f.dimension().filterFunction(function (a) {
                  if (!(a in r)) return !1;
                  var c = r[a].getLatLng();
                  return c && b[0].contains(c);
                }),
                o ||
                  f.map().getBounds().toString === b[0].toString() ||
                  f.map().fitBounds(b[0]));
          },
          F = function (b) {
            if (b.target && f.modKeyMatches(b, f.filterMod())) {
              var c = b.target.key;
              a.events.trigger(function () {
                f.filter(c), a.redrawAll(f.chartGroup());
              });
            }
          };
        return f.anchor(b, e);
      }),
      (d.choroplethChart = function (b, e) {
        var f = d.leafletBase(a.ColorMixin(a.MarginMixin)),
          g = !1,
          h = [],
          i = !1,
          j = !0,
          k = !0,
          l = {
            fillColor: "black",
            color: "gray",
            // opacity: 0.3,
            // fillOpacity: 0.9,
            opacity: 1,
            fillOpacity: 1,
            weight: 1
          },
          m = function (a) {
            return a.key;
          },
          n = function (a) {
            var b = f.featureOptions();
            b instanceof Function && (b = b(a)),
              (b = JSON.parse(JSON.stringify(b)));
            var c = h[f.featureKeyAccessor()(a)];
            return (
              c &&
                c.d &&
                ((b.fillColor = f.getColor(c.d, c.i)),
                f.filters().indexOf(c.d.key) !== -1 &&
                  ((b.opacity = 0.8), (b.fillOpacity = 1))),
              b
            );
          },
          o = function (a, b) {
            return f.title()(a);
          };
        f._postRender = function () {
          (g = c.geoJson(f.geojson(), {
            style: f.featureStyle(),
            onEachFeature: q
          })),
            f.map().addLayer(g);
        };
        const p = f._doRedraw;
        (f._doRedraw = function () {
          return (
            g.clearLayers(),
            (h = []),
            f._computeOrderedGroups(f.data()).forEach(function (a, b) {
              h[f.keyAccessor()(a)] = { d: a, i: b };
            }),
            g.addData(f.geojson()),
            p.call(this)
          );
        }),
          (f.geojson = function (a) {
            return arguments.length ? ((i = a), f) : i;
          }),
          (f.featureOptions = function (a) {
            return arguments.length ? ((l = a), f) : l;
          }),
          (f.featureKeyAccessor = function (a) {
            return arguments.length ? ((m = a), f) : m;
          }),
          (f.featureStyle = function (a) {
            return arguments.length ? ((n = a), f) : n;
          }),
          (f.popup = function (a) {
            return arguments.length ? ((o = a), f) : o;
          }),
          (f.renderPopup = function (a) {
            return arguments.length ? ((j = a), f) : j;
          }),
          (f.brushOn = function (a) {
            return arguments.length ? ((k = a), f) : k;
          });
        var q = function (a, b) {
            var c = h[f.featureKeyAccessor()(a)];
            c &&
              c.d &&
              ((b.key = c.d.key),
              f.renderPopup() && f.bindPopupWithMod(b, f.popup()(c.d, a)),
              f.brushOn() && b.on("click", r));
          },
          r = function (b) {
            if (b.target && f.modKeyMatches(b, f.filterMod())) {
              var c = b.target.key;
              a.events.trigger(function () {
                f.filter(c), a.redrawAll(f.chartGroup());
              });
            }
          };
        return f.anchor(b, e);
      }),
      (d.bubbleChart = function (e, f) {
        function g(b) {
          var c = [];
          l.eachLayer(function (a) {
            var d = a.getLatLng();
            b.boxZoomBounds.contains(d) && c.push(a.key);
          }),
            a.events.trigger(function (a) {
              h.replaceFilter([c]), h.redrawGroup();
            });
        }
        var h = d.leafletBase(a.ColorMixin(a.MarginMixin));
        h.linearColors(["gray"]);
        var i = "blue",
          j = function (a) {
            return h.getColor(a);
          },
          k = !0,
          l = !1,
          m = function (a) {
            return h.keyAccessor()(a);
          },
          n = function (a, b) {
            return h.title()(a);
          },
          o = b.scaleLinear().domain([0, 100]),
          p = !0,
          q = function (a, b) {
            var d = h.locationAccessor()(a),
              e = h.toLocArray(d),
              f = c.latLng(+e[0], +e[1]),
              g = c.circleMarker(f);
            g.setRadius(h.r()(h.valueAccessor()(a))),
              g.on("mouseover", function (a) {
                h.renderPopup && this.openPopup();
              }),
              g.on("mouseout", function (a) {
                h.renderPopup && this.closePopup();
              });
            var i = h.keyAccessor()(a),
              j = -1 !== h.filters().indexOf(i);
            return (
              (g.options.color = j
                ? h.selectedColor()
                : h.unselectedColor()(a)),
              g
            );
          };
        (h.r = function (a) {
          return arguments.length ? ((o = a), h) : o;
        }),
          (h.brushOn = function (a) {
            return arguments.length ? ((p = a), h) : p;
          }),
          (h.locationAccessor = function (a) {
            return arguments.length ? ((m = a), h) : m;
          }),
          (h.selectedColor = function (a) {
            return arguments.length ? ((i = a), h) : i;
          }),
          (h.unselectedColor = function (a) {
            return arguments.length ? ((j = a), h) : j;
          }),
          (h.popup = function (a) {
            return arguments.length ? ((n = a), h) : n;
          }),
          (h.layerGroup = function () {
            return l;
          }),
          (h.renderPopup = function (a) {
            return arguments.length ? ((k = a), h) : k;
          });
        var r = function (a, b) {
          var c = h.marker()(a, h.map());
          return (
            (c.key = b),
            h.renderPopup() && h.bindPopupWithMod(c, h.popup()(a, c)),
            h.brushOn() && c.on("click", s),
            c
          );
        };
        (h.marker = function (a) {
          return arguments.length ? ((q = a), h) : q;
        }),
          (h._postRender = function () {
            h.brushOn() &&
              h.map().on("click", function (a) {
                h.filter(null), h.redrawGroup();
              }),
              h.map().on("boxzoomend", g, this),
              (l = new c.LayerGroup()),
              h.map().addLayer(l);
          }),
          (h._doRedraw = function () {
            var a = h._computeOrderedGroups(h.data()).filter(function (a) {
              return 0 !== h.valueAccessor()(a);
            });
            l.clearLayers(),
              a.forEach(function (a, b) {
                var c = h.keyAccessor()(a),
                  d = null;
                (d = r(a, c)), l.addLayer(d);
              });
          });
        var s = function (a) {
          if (a.target) {
            var b = a.target.key;
            c.DomEvent.stopPropagation(a);
            var b = a.target.key;
            a.originalEvent.ctrlKey || a.originalEvent.metaKey
              ? h.filter(b)
              : h.replaceFilter([[b]]),
              h.redrawGroup();
          }
        };
        return h.anchor(e, f);
      }),
      (d.d3 = b),
      (d.dc = a),
      d
    );
  }
  if ("function" == typeof define && define.amd)
    define(["dc", "d3", "leaflet", "leaflet.markercluster"], a);
  else if ("object" == typeof module && module.exports) {
    var b = require("dc"),
      c = require("d3"),
      d = require("leaflet");
    require("leaflet.markercluster");
    module.exports = a(b, c, d);
  } else this.dc_leaflet = a(dc, d3, this.L);
})();
//# sourceMappingURL=dc.leaflet.min.js.map
